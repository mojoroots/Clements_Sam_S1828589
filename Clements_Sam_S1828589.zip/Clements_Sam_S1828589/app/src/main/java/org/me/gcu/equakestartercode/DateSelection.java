//Clements_Sam_S1828589
package org.me.gcu.equakestartercode;


import android.app.AppComponentFactory;
import android.widget.CalendarView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class DateSelection  extends AppCompatActivity implements CalendarView.OnDateChangeListener

{
    @Override
    public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {

    }
}
