//Clements_Sam_S1828589
package org.me.gcu.equakestartercode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

public  class ItemKeeper {

  //  public static ArrayList<String> itemInfo = new ArrayList<String>();
    public static ArrayList<String> itemTitles = new ArrayList<String>();
    public static ArrayList<String> itemDescription = new ArrayList<String>();
    public static ArrayList<String> itemLink = new ArrayList<String>();
    public static ArrayList<String> itemPubDate = new ArrayList<String>();
    public static ArrayList<String> itemGeoLat = new ArrayList<String>();
    public static ArrayList<String> itemGeoLong = new ArrayList<String>();
    public static ArrayList<Float> itemMag = new ArrayList<Float>();
    //public static ArrayList<String> itemMag = new ArrayList<String>();
    public static ArrayList<String> itemData = new ArrayList<String>();
    public static ArrayList<Date> itemDates = new ArrayList<Date>();
  public static ArrayList<Date> itemDates2 = new ArrayList<Date>();
  public static ArrayList<String> itemShort = new ArrayList<>();
  public static ArrayList<String> itemLong = new ArrayList<>();
  public static ArrayList<Integer> itemDepth = new ArrayList<>();
  public static ArrayList<Date> itemDates3 = new ArrayList<Date>();



}
